<?php
return array(
	//'配置项'=>'配置值'
    'URL_MODEL'=>2,
    'DB_TYPE' => 'mongo',
	'DB_HOST'=> '127.0.0.1',
	'DB_NAME'=>'db',
	'DB_USER'=>'',
	'DB_PWD'=>'',
	'DB_PORT'=>'27017',
    )
?>